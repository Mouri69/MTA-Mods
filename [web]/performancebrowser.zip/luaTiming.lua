-- Lua time recordings config
g_LuaTimingRecordings = {
	EnabledOnServer = true,
    EnabledOnClient = false, -- Enabling this will have a slight performance impact on clients
	Frequency = 5000, -- in milliseconds
	HistoryLength = 100, -- number of records to keep
	HighCPUResourcesAmount = 10, -- percentage threshold
}

-- Global variable to store high usage resources similar to IPB
g_HighUsageResources = {}

-- Date/time formatting function
local function getDateTimeString()
    local time = getRealTime()
    local weekday = ({"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"})[time.weekday + 1]
    -- Weekday, DD.MM.YYYY, hh:mm:ss
    return ("%s, %02d.%02d.%d, %02d:%02d:%02d"):format(weekday, time.monthday, time.month + 1, time.year + 1900, time.hour, time.minute, time.second)
end

function getLuaTimingRecordings( queryFilterText )
	local columns = {"Resource", "CPU Usage", "Recorded Time"}
	local rows = {}
	
	-- Get the global high usage resources if it exists
	if g_HighUsageResources then
		for i, recording in ipairs(g_HighUsageResources) do
			local resourceName = recording[1]
			local cpuUsage = recording[2]
			local recordedTime = recording[3]
			
			-- Apply filter if specified
			if not queryFilterText or queryFilterText == "" or string.find(string.lower(resourceName), string.lower(queryFilterText), 1, true) then
				table.insert(rows, {resourceName, cpuUsage, recordedTime})
			end
		end
	end
	
	return columns, rows, true
end

-- Save high CPU resources function (based on IPB alarm.lua)
function saveHighCPUResources()
    local columns, rows = getPerformanceStats("Lua timing")
	
    if not rows then
        return
    end

    for index, row in pairs(rows) do
        local usageText = row[2]:gsub("[^0-9%.]", "")
        local usage = math.floor(tonumber(usageText) or 0)

        if (usage > g_LuaTimingRecordings.HighCPUResourcesAmount) then
            -- Record this high usage to table
            table.insert(g_HighUsageResources, 1, {row[1], row[2], getDateTimeString()})

            -- Make sure it won't get too big
            if #g_HighUsageResources > g_LuaTimingRecordings.HistoryLength then
                table.remove(g_HighUsageResources, g_LuaTimingRecordings.HistoryLength)
            end
        end
    end
end