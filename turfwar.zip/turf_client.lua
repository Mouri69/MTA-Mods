-- Debug
outputDebugString("[TurfWar] Client script loaded!", 3)
outputChatBox("[TurfWar] Turf War system loaded! Press F5 to join a gang.", 0, 255, 0, false)

local isMenuOpen = false
local screenW, screenH = guiGetScreenSize()

local menuX = screenW * 0.3
local menuY = screenH * 0.3
local menuWidth = 400
local menuHeight = 250

-- UI elements
local uiElements = {
    bg = {x = menuX, y = menuY, width = menuWidth, height = menuHeight},
    header = {x = menuX, y = menuY, width = menuWidth, height = 40},
    mouriBtn = {x = menuX + 20, y = menuY + 60, width = 160, height = 40},
    evilBtn = {x = menuX + 220, y = menuY + 60, width = 160, height = 40}
}

function drawMenu()
    if not isMenuOpen then return end
    
    -- Draw background
    dxDrawRectangle(uiElements.bg.x, uiElements.bg.y, uiElements.bg.width, uiElements.bg.height, tocolor(0, 0, 0, 220))
    
    -- Draw borders
    dxDrawRectangle(uiElements.bg.x, uiElements.bg.y, uiElements.bg.width, 4, tocolor(150, 0, 0, 255))  -- top
    dxDrawRectangle(uiElements.bg.x, uiElements.bg.y + uiElements.bg.height - 4, uiElements.bg.width, 4, tocolor(150, 0, 0, 255))  -- bottom
    dxDrawRectangle(uiElements.bg.x, uiElements.bg.y, 4, uiElements.bg.height, tocolor(150, 0, 0, 255))  -- left
    dxDrawRectangle(uiElements.bg.x + uiElements.bg.width - 4, uiElements.bg.y, 4, uiElements.bg.height, tocolor(150, 0, 0, 255))  -- right
    
    -- Draw header
    dxDrawRectangle(uiElements.header.x, uiElements.header.y, uiElements.header.width, uiElements.header.height, tocolor(100, 0, 0, 255))
    dxDrawText("Turf War - Join a Gang", uiElements.header.x + 20, uiElements.header.y + 10, uiElements.header.x + uiElements.header.width, uiElements.header.y + uiElements.header.height, tocolor(255, 255, 255, 255), 1, "default-bold", "left", "center")
    
    -- Draw Mouri button
    local mouriHover = isMouseOver(uiElements.mouriBtn.x, uiElements.mouriBtn.y, uiElements.mouriBtn.width, uiElements.mouriBtn.height)
    dxDrawRectangle(uiElements.mouriBtn.x, uiElements.mouriBtn.y, uiElements.mouriBtn.width, uiElements.mouriBtn.height, tocolor(mouriHover and 150 or 100, 0, 0, 255))
    dxDrawText("Join Mouri", uiElements.mouriBtn.x + 10, uiElements.mouriBtn.y + 10, uiElements.mouriBtn.x + uiElements.mouriBtn.width, uiElements.mouriBtn.y + uiElements.mouriBtn.height, tocolor(255, 255, 255, 255), 1, "default-bold", "center", "center")
    
    -- Draw Evil button
    local evilHover = isMouseOver(uiElements.evilBtn.x, uiElements.evilBtn.y, uiElements.evilBtn.width, uiElements.evilBtn.height)
    dxDrawRectangle(uiElements.evilBtn.x, uiElements.evilBtn.y, uiElements.evilBtn.width, uiElements.evilBtn.height, tocolor(evilHover and 150 or 100, 0, 0, 255))
    dxDrawText("Join Evil", uiElements.evilBtn.x + 10, uiElements.evilBtn.y + 10, uiElements.evilBtn.x + uiElements.evilBtn.width, uiElements.evilBtn.y + uiElements.evilBtn.height, tocolor(255, 255, 255, 255), 1, "default-bold", "center", "center")
end

function isMouseOver(x, y, width, height)
    local cursorX, cursorY = getCursorPosition()
    if cursorX and cursorY then
        cursorX, cursorY = cursorX * screenW, cursorY * screenH
        return cursorX >= x and cursorX <= x + width and cursorY >= y and cursorY <= y + height
    end
    return false
end

function handleMenuClick(button, state)
    if not isMenuOpen or button ~= "left" or state ~= "down" then return end
    
    if isMouseOver(uiElements.mouriBtn.x, uiElements.mouriBtn.y, uiElements.mouriBtn.width, uiElements.mouriBtn.height) then
        triggerServerEvent("turfwar:joinGang", localPlayer, "Mouri")
        toggleMenu()
    elseif isMouseOver(uiElements.evilBtn.x, uiElements.evilBtn.y, uiElements.evilBtn.width, uiElements.evilBtn.height) then
        triggerServerEvent("turfwar:joinGang", localPlayer, "Evil")
        toggleMenu()
    end
end

function toggleMenu()
    isMenuOpen = not isMenuOpen
    if isMenuOpen then
        addEventHandler("onClientRender", root, drawMenu)
        addEventHandler("onClientClick", root, handleMenuClick)
        showCursor(true)
    else
        removeEventHandler("onClientRender", root, drawMenu)
        removeEventHandler("onClientClick", root, handleMenuClick)
        showCursor(false)
    end
end

function toggleMenuKey(key, keyState)
    if keyState == "down" then
        outputDebugString("[TurfWar] F5 pressed!", 3)
        toggleMenu()
    end
end

bindKey("F5", "down", toggleMenuKey)
